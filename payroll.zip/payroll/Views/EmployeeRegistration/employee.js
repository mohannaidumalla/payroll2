$(document).ready(function(){
function preprocessing(obj){
    var s = "[";
    for(i in obj){
      s += "\"" + obj[i] + "\"" + ",";
    }
    s = s.substring(0,s.length - 1)
    s += "]";
    return s;
  } 
  function getPublicKey(x){
    $.post("https://node1.belrium.io/api/accounts/open",
      {secret:x,countryCode:"IN"},
      function(data){
        if(data.isSuccess===true)
        {
          return data.publicKey;
        }
        else
        {
          return 0;
        }
        });
  }
  
$("#register").click(function(){  
    var secret=window.prompt("Enter Secret: ");
    var paras={
    countryCode:$("#countryCode").val(),
    email:$("#email").val(),
    lastName:$("#lastName").val(),
    name:$("#name").val(),
    uuid:$("#uuid").val(),
    designation:$("#designation").val(),
    bank:$("#bank").val(),
    accountNumber:$("#accountNumber").val(),
    pan:$("#pan").val(),
    salary:$("#salary").val()
    };
    var arg=preprocessing(paras);
    var params={
      args:arg,
      type: 1007,
      fee:"0",
      secret:secret,
      publicKey:getPublicKey(secret)
    };
    if(paras.token!==0 && paras.token!==-1)
    {
    $.ajax({
      url: 'http://54.251.138.1:9305/api/dapps/8d2ad02c847eb9aaab012bb27e8f681639e93291f837596f40458f2cecedb591/transactions/unsigned/',
      type: 'PUT',
      data: params,
      success: function(response) {
        alert(JSON.stringify(response));
        if(response.success===true)
        {
          window.location.href="../Dashboard/Dashboard.html";
        }
        else
        {
          $("#errormsg").html("Failed to register");
        }
      }
      });

    }
    else
    {
        alert("Can not generate access token");
    }
  });
});
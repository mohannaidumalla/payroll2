$(document).ready(function(){
    var querystring=decodeURIComponent(window.location.search);
    querystring=querystring.substring(1);
    var queries=querystring.split("=");
    var eid=queries[0];
    var mon=queries[1];
    var yr=queries[2];
    $.post("http://54.251.138.1:9305/api/dapps/8d2ad02c847eb9aaab012bb27e8f681639e93291f837596f40458f2cecedb591/employeeData/",{empid:eid},function(data){
      if(data.empID===eid )
      {
        document.getElementById("txtemail").setAttribute("value",data.email);
        document.getElementById("txtemployeeid").setAttribute("value",data.empID);
        document.getElementById("txtempname").setAttribute("value",data.name);
        document.getElementById("txtdesignation").setAttribute("value",data.designation);
        document.getElementById("txtbs").setAttribute("value",data.salary);
        document.getElementById("txtmonth").setAttribute("value",mon);
        document.getElementById("txtyear").setAttribute("value",yr);
      }
      else
      {
        alert("Employee does not exists");
      }
  });
  function getPublicKey(x){
    $.post("https://node1.belrium.io/api/accounts/open",
      {secret:x,countryCode:"IN"},
      function(data){
        if(data.isSuccess===true)
        {
          return data.publicKey;
        }
        else
        {
          return 0;
        }
        });
  }

  function preprocessing(obj){
    var s = "[";
    for(i in obj){
      s += "\"" + obj[i] + "\"" + ",";
    }
    s = s.substring(0,s.length - 1)
    s += "]";
    return s;
  } 

  function calcGrossSalary(basicPay,hra,lta,ma){
    return parseInt(basicPay) + parseInt(hra) + parseInt(lta) + parseInt(ma);
    }

  function calcTotalDeductions(providentFund,professionalTax){
    return parseInt(providentFund) + parseInt(professionalTax);
  }  

  function calcNetSalary(gross, totalDed){
    return gross - totalDed;
  }

  //transaction call
  $("#issuecert").click(function(){ 
    var secret=$("#secret").val();
    var basicPay=$("#txtbs").val();
    var hra=$("#txthra").val();
    var lta=$("#txtlta").val();  
    var ma=$("#txtma").val();
    var providentFund=$("#txtpf").val();
    var professionalTax=$("#txtpt").val();
    var grossSalary=calcGrossSalary(basicPay,hra,lta,ma);
    var totalDeductions=calcTotalDeductions(providentFund,professionalTax);
    var netSalary=calcNetSalary(grossSalary, totalDeductions);

    var paras={
        email:$("#txtemail").val(),
        empid:$("#txtemployeeid").val(),
        name:$("#txtempname").val(),
        employer:"Belfrics Crptex Pvt. Ltd.",
        month:$("#txtmonth").val(),
        year:$("#txtyear").val(),
        designation:$("#txtdesignation").val(),
        bank:$("#txtbankname").val(),
        accountNumber:$("#txtacno").val(),
        pan:$("#txtpan").val(),
        basicPay:basicPay,
        hra:hra,
        lta:lta,
        ma:ma,
        providentFund:providentFund,
        professionalTax:professionalTax,
        grossSalary:grossSalary,
        totalDeductions:totalDeductions,
        netSalary:netSalary,
        secret:secret
    };
    var arg=preprocessing(paras);
    var params={
      args:arg,
      type: 1003,
      fee:"0",
      secret:secret,
      publicKey:getPublicKey(),
      countryCode:"IN"
    };

    //display pay slip
    $("#disp_month").html(paras.month);
    $("#disp_year").html(paras.year);
    $("#disp_employeeid").html(paras.empid);
    $("#disp_ename").html(paras.name);
    $("#disp_bankname").html(paras.bank);
    $("#disp_designation").html(paras.designation);
    $("#disp_acno").html(paras.accountNumber);
    $("#disp_pan").html(paras.pan);
    $("#disp_bs").html(paras.basicPay);
    $("#disp_hra").html(paras.hra);
    $("#disp_lta").html(paras.lta);
    $("#disp_ma").html(paras.ma);
    $("#disp_grosssalary").html(paras.grossSalary);
    $("#disp_pf").html(paras.providentFund);
    $("#disp_pt").html(paras.professionalTax);
    $("#disp_td").html(paras.totalDeductions);
    $("#disp_netsalary").html(paras.netSalary);

    $.ajax({
      url: 'http://54.251.138.1:9305/api/dapps/8d2ad02c847eb9aaab012bb27e8f681639e93291f837596f40458f2cecedb591/transactions/unsigned/',
      type: 'PUT',
      data: params,
      success: function(response) {
        if(response.success===true)
        {
          alert("Successfully issued certificate")
          window.location.href="../Dashboard/Dashboard.html";
        }
        else
        {
          $("#errormsg").text("Failed to issue certificate");
        }
      }
      });
  });
});
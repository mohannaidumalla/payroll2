$(document).ready(function(){
    var querystring=decodeURIComponent(window.location.search);
    querystring=querystring.substring(1);
    var queries=querystring.split('=');
    var email,password;
    if(queries[1]!=="")
        {
            email=queries[1];
            document.getElementById("email").setAttribute("value",email);
        }
        $("#login").click(function(){   
        email=$("#email").val();
        password=$("#password").val();
        $.post("http://54.251.138.1:9305/api/dapps/8d2ad02c847eb9aaab012bb27e8f681639e93291f837596f40458f2cecedb591/userlogin/",
        {email: email,password: password},
        function(data){
            if(data.isSuccess===true)
            {
                window.location.href="../Wallet1/Wallet1.html"+"?"+data.data.email;
            }
           else
            {
                $("#message").html("Username or Password is incorrect");
            }
        });
    });
});
$(document).ready(function(){
    var name,email,password,type,countryCode,countryId;
    $("#register").click(function(){
        countryId=$("#countryId").val()
        countryCode=$("#countryCode").val();
        email=$("#email").val();
        name=$("#name").val();
        password=$("#password").val();
        type="merchant";
        $.post("http://54.251.138.1:9305/api/dapps/8d2ad02c847eb9aaab012bb27e8f681639e93291f837596f40458f2cecedb591/usersignup/",
        {countryId:countryId,countryCode:countryCode,emailid:email,name:name,password:password,type:type},
        function(data)
        {
            if(data==="success")
            {
                window.location.href="../Login/Login.html?email="+email;
            }
            else{
                $("#errormsg").text("Failed to Register");
            }
        }
        );
    });
});

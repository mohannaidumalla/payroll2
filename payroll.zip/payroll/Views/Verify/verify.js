$(document).ready(function(){
    var jData;
    var querystring=decodeURIComponent(window.location.search);
    querystring=querystring.substring(1);
    document.getElementById("json").setAttribute("value",querystring);
    $("#verify").click(function(){
        jData={
            data: $("#json").val()
        }
        $.post("http://54.251.138.1:9305/api/dapps/8d2ad02c847eb9aaab012bb27e8f681639e93291f837596f40458f2cecedb591/verifypayslip/",
        jData,
        function(dataf,status){
        if(dataf==="Hash not found")
        {    
        $("#msg").html(dataf);
        }
       else{
           window.location.href="../Verifier/verifier.html?"+JSON.stringify(dataf)+"`"+jData.data;
       }   
});
    });
});
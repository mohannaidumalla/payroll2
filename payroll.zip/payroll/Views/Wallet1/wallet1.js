$(document).ready(function(){
    var secret,countryCode;
    var user=decodeURIComponent(window.location.search);
    user=user.substring(1);
    var username=user.split('&');
    $("#show").click(function(){
    secret=$("#passphrase").val();
    countryCode="IN";
    $.post("http://node1.belrium.io/api/accounts/open",{secret,countryCode},function(data){
        var querystring="?" + data.account.address + "&" + data.account.balance +"&" + username[0];
        window.location.href="../Wallet2/Wallet2.html" + querystring;
       });
    });
});
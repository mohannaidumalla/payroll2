$(document).ready(function(){
    var querystring=decodeURIComponent(window.location.search);
    querystring=querystring.substring(1);
    var queries=querystring.split('&');
    var address="";
    for(var i=0;i<queries[0].length;i+=4){
        if(i+4>=queries[0].length)
        {
            address=address.concat(queries[0].substring(i,i+4));
        }
        else
        {
            address=address.concat(queries[0].substring(i,i+4)+"-");
        }
    }
    $("#addr").empty().html(address);
    $("#balan").empty().html(queries[1]);
    $("#username").empty().html(queries[2]);
});